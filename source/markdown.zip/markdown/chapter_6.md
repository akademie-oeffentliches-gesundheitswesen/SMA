---
layout: page
title: Annex-Abkürzungen
nav_order: 6
---
 
<details markdown="block"> 
  <summary> 
      &#9658; Inhaltsverzeichnis Kapitel (ausklappbar) 
  </summary>
 
1. TOC
{:toc}
 </details>
 
   <p></p>
 
 
**APO-SMA** Ausbildungs- und Prüfungsordnung für sozialmedizinische
Assistentinnen und Assistenten

**BfR** Bundesinstitut für Risikobewertung

**BKiSchG** Bundeskinderschutzgesetzes

**BzGA** Bundeszentrale für gesundheitliche Aufklärung

**GBE** Gesundheitsberichterstattung

**HIV** Humanes-Immundefizienz Virus

**IfSG** Infektionsschutzgesetz

**KGJD** Kinder- und Jugendgesundheits Dienst

**ÖGD** Öffentlicher Gesundheitsdienst

**PrävG** Gesetz zur Stärkung der Gesundheitsförderung und Prävention
(Präventionsgesetz)

**RKI** Robert Koch-Institut

**SEU** Schuleingangsuntersuchungen

**SGFK** Schulgesundheitsfachkräften

**SGS** Schulgesundheitsschwestern

**SMA** Sozialmedizinische (Assistent/in) Fachangestellte

**SpDi** Sozialpsychiatrischer Dienst

**STI** sexuell übertragbare Infektionskrankheiten

<div class="section fnlist" data-role="doc-footnotes">

</div>
