---
layout: page
title: a. Beteiligte
nav_order: 8
---
 
<details markdown="block"> 
  <summary> 
      &#9658; Inhaltsverzeichnis Kapitel (ausklappbar) 
  </summary>
 
1. TOC
{:toc}
 </details>
 
   <p></p>
 
 
## Autoreninnen

**Birgit Abt**

Amt 7 Gesundheitsamt, Kreisverwaltung Bad Kreuznach

 

**Kaija Elvermann**

Gesundheitsamt, Oberbergischer Kreis

 

**Petra Haas**

Gesundheitsamt, Region Kassel

 

**Anja Haupt**

Fachdienst 553 Gesundheit, Stadt Emden

 

**Birgit Hausfeld    **       

Gesundheitsamt, Landkreis Oldenburg

 

**Rita Krämer-Stamm**

Fachbereich 7 Gesundheit, Soziales und Verbraucherschutz, Märkischer
Kreis

 

**Antje Rehbock    **      

Abteilung Gesundheit, Landkreis Harburg

 

**Dr. Dagmar Starke**

Akademie für Öffentliches Gesundheitswesen

 

**Karina Stelter**

Abteilung Gesundheit, Landkreis Harburg

## Anerkennung & Danksagung

**Anna Eckhard**t und **Lambert Heller** für die Unterstützung bei der
Entwicklung des Projektes und der Durchführung der Book Sprints.

**Dr. med. Jakob Schumacher** und **Simon Worthington** für die
Unterstützung bei der Umsetzung des Projektes und die technische
Umsetzung auf GitHub.

**Bernd Schiller** und **Petra Münstedt** für die sorgfältige Durchsicht
und umsichtigen Korrekturen des gesamten Werkes.

**Johannes Wilm** und das **[FidusWriter.org
Team](https://www.fiduswriter.org/who-we-are/ "https://www.fiduswriter.org/who-we-are/")**
für die technische Unterstützung.

Dem **Bundesministerium für Gesundheit**, das die gemeinsame Erarbeitung
unseres Lehrbuches gefördert hat. Ohne diese Unterstützung wäre das
Projekt nicht möglich gewesen.

**Dr. med. Ute Teichert** und **Dr. Peter Tinnemann** für den
Enthusiasmus und die tatkräftige Unterstützung des Projektes.

<div class="section fnlist" data-role="doc-footnotes">

</div>
